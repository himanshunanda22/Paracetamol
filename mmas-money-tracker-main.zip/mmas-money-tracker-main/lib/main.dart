// @dart=2.9


import 'package:money_assistant_2608/project/real_main.dart';

void main() async {
  realMain();
}
